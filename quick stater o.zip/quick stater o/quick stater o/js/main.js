(function ($) {
  "use script";

















}) (jQuery);